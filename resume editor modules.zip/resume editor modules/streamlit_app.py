import os
from dotenv import load_dotenv
import streamlit as st
#from google import genai
import google.generativeai as genai

load_dotenv(override=True)

st.title("AI Resume Builder")

#GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
GOOGLE_API_KEY='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'
print("GOOGLE_API_KEY:::::::::::::::::::"+GOOGLE_API_KEY)
if not GOOGLE_API_KEY:
    st.error("Set GOOGLE_API_KEY in .env or environment.")
    st.stop()

# create client to interact with the API
# Below
# client = genai.Client(api_key=GOOGLE_API_KEY)
client=genai.configure(api_key="GOOGLE_API_KEY")
# sample inputs (you can replace these or provide UI fields)
resume_text = st.text_area("Resume", value=" ", height=200)
job_text = st.text_area("Job description", value=" ", height=200)

# model_choice = st.selectbox("model", ["gemini-2.5-flash","gemini-2.0-flash", "gemini-1.5-flash", "gemini-pro"])
model = genai.GenerativeModel("llama-3.1-8b-instant")
# model = genai.GenerativeModel("gemini-1.5-flash")

temp = st.slider("Temperature", 0.0, 1.0, 0.7)
max_tokens = st.number_input("Max tokens", min_value=64, max_value=2000, value=800)

# Gemini API responses may store text in different attributes (.text or .output_text), depending on the SDK version.
def extract_text(resp):
    if hasattr(resp, "text") and resp.text:
        return resp.text
    if hasattr(resp, "output_text") and resp.output_text:
        return resp.output_text
    try:
        return str(resp)
    except Exception:
        return "<no text>"

def build_prompt(resume, job):
    return f"""
Context:
    You are a professional career advisor and resume writer. Analyze the candidate's resume against the provided job description to assess alignment and identify areas for improvement. 

    Tasks:
    1. Summarize key requirements from the Job Description.  
    2. Highlight relevant experience from the Resume that matches those requirements.  
    3. Identify gaps or missing skills, especially in AI areas (Prompt Engineering, ChatGPT, GenAI, Agentic AI).  
    4. Highlight additional strengths from the Resume that add value.  
    5. Rewrite and enhance the Resume tailored for this job, ensuring:  
    - Suitability Score (out of 100) 
    - Strong action verbs and quantifiable results.  
    - Emphasis on relevant skills/experience.  
    - AI-related skills (Prompt engineering, ChatGPT, LLMs, Agentic AI) are clearly showcased.  
    - Resume is well-formatted and impactful.

Input:
Resume:
{resume}

Job Description:
{job}

Output:
    - Analysis (sections 1–4 as above).  
    - Updated, improved resume.
"""

if st.button("Generate Improved Resume"):
    if not resume_text.strip() or not job_text.strip():
        st.warning("Please provide both resume and job description.")
    else:
        prompt = build_prompt(resume_text, job_text)
        with st.spinner("Analyzing & Rewriting Enhanced Resume..."):
            # Send a single combined string as contents to match most SDK versions
            try:
                # resp = client.models.generate_content(
                resp =model.generate_content(
                    # model=model_choice,
                    # model,
                    contents=[prompt]
                )
                out = extract_text(resp)
            except Exception as e:
                out = f"Error calling Gemini: {e}"
        st.subheader("Improved Resume")
        # Markdown is used for formatting plain text documents
        st.markdown(out)