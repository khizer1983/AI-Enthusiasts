# app.py
# Stock Analysis AI with CrewAI and Groq

import streamlit as st
import os
from crewai import Agent, Task, Crew, LLM
from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field
import yfinance as yf
from serpapi import GoogleSearch
import warnings
warnings.filterwarnings('ignore')

# Page config
st.set_page_config(
    page_title="Stock Analysis AI",
    page_icon="📈",
    layout="wide"
)

st.title("📈 AI Stock Analysis System")
st.markdown("Multi-agent system powered by CrewAI and Groq")

# Sidebar for API keys
with st.sidebar:
    st.header("🔑 API Configuration")
    
    groq_key = st.text_input("Groq API Key (gsk_...)", type="password")
    st.markdown("[Get GroqKey](https://console.groq.com/keys)")
    
    serpapi_key = st.text_input("SerpAPI Key", type="password")
    st.markdown("[Get SerpAPIKey](https://serpapi.com/)")
    
    st.markdown("---")
    st.info("Groq is FREE with fast inference!")

# Check if keys are provided
if not groq_key or not serpapi_key:
    st.warning("Please enter your API keys in the sidebar to continue")
    st.stop()

# Set environment variables
os.environ["GROQ_API_KEY"] = groq_key
os.environ["SERPAPI_API_KEY"] = serpapi_key

# Initialize LLM
@st.cache_resource
def get_llm(_groq_key):
    return LLM(
        model="groq/llama-3.3-70b-versatile",
        api_key=_groq_key,
        temperature=0.7
    )

llm = get_llm(groq_key)

# Define Tools
class StockSearchInput(BaseModel):
    query: str = Field(..., description="Search query")

class YahooFinanceInput(BaseModel):
    ticker: str = Field(..., description="Stock ticker")

class StockSearchTool(BaseTool):
    name: str = "StockNewsSearcher"
    description: str = "Search stock news"
    args_schema: Type[BaseModel] = StockSearchInput
    
    def _run(self, query: str) -> str:
        try:
            params = {
                "engine": "google",
                "q": query,
                "api_key": os.environ.get("SERPAPI_API_KEY"),
                "tbm": "nws",
                "num": 3
            }
            search = GoogleSearch(params)
            results = search.get_dict()
            news = results.get("news_results", results.get("organic_results", []))
            
            if not news:
                return "No news found"
            
            output = []
            for item in news[:3]:
                title = item.get("title", "")
                snippet = item.get("snippet", "")
                output.append(f"• {title}: {snippet[:100]}")
            
            return "\n".join(output)
        except:
            return "Error fetching news"

class YahooFinanceTool(BaseTool):
    name: str = "YahooFinanceFetcher"
    description: str = "Get stock price data"
    args_schema: Type[BaseModel] = YahooFinanceInput
    
    def _run(self, ticker: str) -> str:
        try:
            stock = yf.Ticker(ticker)
            hist = stock.history(period="1mo")
            
            if hist.empty:
                return "No data"
            
            latest = hist.tail(5)
            current = latest['Close'].iloc[-1]
            change = ((latest['Close'].iloc[-1] - latest['Close'].iloc[0]) / latest['Close'].iloc[0]) * 100
            
            return f"""Price: ${current:.2f}
5-day Change: {change:+.2f}%
High: ${latest['High'].max():.2f}
Low: ${latest['Low'].min():.2f}"""
        except:
            return "Error fetching data"

# Initialize tools
search_tool = StockSearchTool()
finance_tool = YahooFinanceTool()

# Create Agents
@st.cache_resource
def get_agents(_llm):
    analyst = Agent(
        role='Stock Analyst',
        goal='Analyzestocks',
        backstory='Financial expert',
        verbose=False,
        llm=_llm,
        tools=[search_tool, finance_tool]
    )
    
    writer = Agent(
        role='Report Writer',
        goal='Write reports',
        backstory='Financial writer',
        verbose=False,
        llm=_llm
    )
    
    return analyst, writer

analyst, writer = get_agents(llm)

# Main interface
col1, col2 = st.columns([2, 1])

with col1:
    ticker = st.text_input("Enter Stock Ticker", value="AAPL", max_chars=10).upper()

with col2:
    analyze_btn = st.button("🔍Analyze Stock", type="primary", use_container_width=True)

if analyze_btn:
    if not ticker:
        st.error("Please enter a stock ticker")
    else:
        with st.spinner(f"Analyzing {ticker}..."):
            try:
                # Create tasks
                news_task = Task(
                    description=f"Search latest news for {ticker} stock",
                    expected_output="News summary",
                    agent=analyst
                )
                
                price_task = Task(
                    description=f"Analyze {ticker} price trends",
                    expected_output="Price analysis",
                    agent=analyst
                )
                
                report_task = Task(
                    description=f"""Write investment report for {ticker}.
                    Include: Summary, News, Price Analysis, Outlook.
                    Keep under 300 words.""",
                    expected_output="Investment report",
                    agent=writer
                )
                
                # Create and run crew
                crew = Crew(
                    agents=[analyst, writer],
                    tasks=[news_task, price_task, report_task],
                    verbose=False
                )
                
                result = crew.kickoff()
                
                # Convert result to string and escape dollar signs
                result_text = str(result).replace('$', r'\$')
                
                # Display results
                st.success("Analysis Complete!")
                
                st.markdown("---")
                st.markdown(f"## 📊 Investment Report - {ticker}")
                st.markdown(result_text)
                st.markdown("---")
                
                # Download button
                st.download_button(
                    label="📥 Download Report",
                    data=str(result),
                    file_name=f"{ticker}_analysis.txt",
                    mime="text/plain"
                )
                
            except Exception as e:
                st.error(f"Error: {str(e)}")

# Footer
st.markdown("---")
st.markdown("**Powered by CrewAI, Groq, and SerpAPI**")

# Commands Terminal
# pip install streamlitcrewaicrewai-tools openaiyfinance google-search-results
# python.exe -m pip install --upgrade pip
# pip install streamlit crewai crewai-tools openai yfinance google-search-results
# streamlit run app.py 